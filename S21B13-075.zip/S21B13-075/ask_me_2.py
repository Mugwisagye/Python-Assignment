name = input("What is your lovely name? ")
name = name.title()
if name == "Timothy":
    print("Welcome, " , name)
else:
    print("Hello, stranger.")

